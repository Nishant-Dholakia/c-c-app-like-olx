								BOSSAA - Buy Or Sell Supplies Anytime Anywhere

								(to fulfill Customer - Customer services)

					Sr. No.		Roll. No.		Enrollment id.			Name
							
					1.		CE071			23CEUOS037			Dholakia Nishant Ashit

					2.		CE072			23CEUOF038			DHORAJIYA GOPAL SANJAYBHAI

					3.		CE066			23CEUOZ029			DALSANIYA OMKUMAR BHAVESHBHAI	


				->	Software used 	:	Codeblocks
			
				->	To compile	:	Press build button (symbol : settings )
	
				->	To execute	:	Press run button (symbol : right arrow key)

		-> Major functionalities of project :
			
			~	We have used file handeling .
			~	There is signup and login page ,  Category page , process for buying and selling product , Admin portal page .

		-> Flow of the project : 

			~ First , it is asked if you want to retrieve old data. Then , welcome page comes .
			~ Now it will be asked to login , signup or login to admin portal or exit the program .
			~ In admin portal , we can check number of users and revenue . 
			~ After login or signup , we go to category page and there 6 options will be shown . Choose any one category and 
			  option for buy or sell will be shown .	
			~ Then if you want to buy , then the list of respective product will be shown and you can make purchases .
			~ If you want to sell a product , then we will take all details of product for sale and keep for display in buy section .